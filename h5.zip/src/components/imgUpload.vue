<template>
  <div class="upload-wrap">
     <input type="file"  size="1" id="file" name="file" :ref="'myFile'" accept="image/png,image/gif,image/jpeg" @change="fileChange($event)" capture="camera" style="display:none"/>
    <i class="fa fa-plus" style="font-size: 2rem;" @click="uploadAction('myFile')" v-show="!image" aria-hidden="true"></i>
    <span v-show="!image">{{placeholder}}</span>
  </div>
</template>

<script>
export default {
  name: 'ImgUpload',
  data () {
    return {
      image: null
    }
  },
  props: {
    placeholder: {
      type: String,
      default: "上传图片"
    }
  },
  methods: {
    fileChange(){

    },
    uploadAction: function (myFile) {
        this.$refs[myFile].click();
    },
    fileChange: function (e) {
        let fileName = e.target.value;
        const extName = fileName.substring(fileName.lastIndexOf('.') + 1);

        if (e.target.value === '') {
            return false;
        }

        // const isLt2M = e.target.files[0].size / 1024 / 1024 < 10;
        // if (!isLt2M) {
        //     this.$message.warning('文件大小10M以内');
        //     return;
        // }
        this.upload(e.target.files[0])
    },
    upload(file) {
        let form = new FormData();
        form.append("upfile ", file);
        this.$http.post('https://wx.sharkmeida.cn/distribution/upload', form).then(({data}) => {
          if(data.code == '0000'){
            this.image = data.result.data
            this.$emit('uploadCallback', data.result.data);
          }
        })
      },
    
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.upload-wrap{
  height: 100%;
  border: 1px dashed #2196f3;
  border-radius: 5px;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  color: #2196f3;
  color: 0.3rem;
  align-items: center;
}
</style>
