<template>
		<transition name="fade-in">
            <div>
                <div id="contentBox" >
                    <div class="circular" ><i class="fa fa-music" aria-hidden="true" style="color:#fff;"></i><audio id="audio2" :src="formD.music.path"  loop="loop"></audio></div>
                    <div class="header">
                        <img src="../assets/bg.png" class="header-img">
                    </div>
                    <div class="middle">
                        <div class="head-cell">
                            <div>
                                <span><i class="fa fa-eercast" aria-hidden="true"></i> 目标量</span>
                                <span>{{formD.targetQuantity}}</span>
                            </div>
                            <div class="line"></div>
                            <div>
                                <span><i class="fa fa-snowflake-o" aria-hidden="true"></i> 参与者</span>
                                <span>0</span>
                            </div>
                            <div class="line"></div>
                            <div>
                                <span><i class="fa fa-share-alt" aria-hidden="true"></i> 访问量</span>
                                <span>{{formD.visits}}</span>
                            </div>    
                        </div>   
                         <count-down v-if="!!formD.endTime" :startTime="formD.startTime" :endTime="formD.endTime"  endText="已经结束了"></count-down>
                         <div class="wrap-2">
                             <div class="img"><img width="100%" height="100%" src="../assets/logo.jpg" /></div>
                             <div class="text">
                                 <span style="font-size: 0.3rem;">鲨鱼传媒-孙Techer</span>
                                 <span style="color: #a5a5a5;">邀请您参与本活动，机不可失，失不再来哦！</span>
                             </div>
                         </div>
                         <div class="wrap-3">
                             <div v-for="(item, index) in users" :key="index">
                                 <img :src="item.headimgurl"/>
                                 <span>{{item.username}}</span>
                             </div>
                         </div>
                        <div class="panel">
                            <span class="panel-head">购买记录</span>
                            <div>
                                <scroll :list="order"></scroll>
                            </div>
                        </div>
                        <div class="panel"  v-if="!!formD.activityRules">
                            <span class="panel-head">活动介绍</span>
                            <div>
                                <div v-for="item in JSON.parse(formD.activityRules)" :key="item.key" style="">
                                    <img v-if="item.type == 'uploadImg'" :src="item.img"  style=" width: 10rem;display: block;"/>
                                    <span v-if="item.type == 'uploadText'" style="width:8.4rem;font-size: 0.4rem;font-weight: bold;padding:0.8rem;word-wrap: break-word;line-height: 0.6rem;display: inline-block;">{{item.img}}</span>
                                    <video v-if="item.type == 'uploadVedio'" width="100%" height="240" controls>
                                        <source :src="item.img" type="video/ogg">
                                        您的浏览器不支持Video标签。
                                    </video>
                                </div>
                            </div>
                        </div>
                        <div class="panel" v-if="!!formD.activityDestription">
                            <span class="panel-head">创建活动说明</span>
                            <div>
                                <div v-for="item in JSON.parse(formD.activityDestription)" :key="item.key" style="">
                                    <img v-if="item.type == 'uploadImg'" :src="item.img"  style=" width: 10rem;display: block;"/>
                                    <span v-if="item.type == 'uploadText'" style="width:8.4rem;font-size: 0.4rem;font-weight: bold;padding:0.8rem;word-wrap: break-word;line-height: 0.6rem;display: inline-block;">{{item.img}}</span>
                                    <video v-if="item.type == 'uploadVedio'" width="100%" height="240" controls>
                                        <source :src="item.img" type="video/ogg">
                                        您的浏览器不支持Video标签。
                                    </video>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
		</transition>
</template>

<script>
import {
  Group,
  Cell,
  Loading,
  Datetime,
  XInput,
  XNumber,
  XSwitch,
  XTextarea
} from "vux";
import CountDown from "./count-down.vue";
import Data from "./data.js";
import Scroll from "./scroll.vue";
//id =  95ce4038a19b49f5bfedb8722eef9ecf
var reg = /\?id=(\w+)&?/;
reg.test(location.href);
const url = "https://wx.sharkmeida.cn/distribution/info/" + RegExp.$1;
console.log(url);
export default {
  name: "info",
  components: {
    Group,
    Cell,
    Loading,
    Datetime,
    XInput,
    XNumber,
    XSwitch,
    XTextarea,
    Scroll,
    CountDown
  },
  data() {
    return {
      users: [],
      order: [],
      formD: Data,
      isLoading: true,
      musicUrl: ""
    };
  },
  props: {
    form: {
      type: Object
    }
  },
  mounted() {
    this.query();
  },
  methods: {
    stop() {
      var audio = document.getElementById("audio2");
      if (audio == null) return;
      audio.pause();
    },
    play(item) {
      var audio = document.getElementById("audio2");
      if (audio == null) return;
      if (this.formD.autoPlayMusic) {
        let data = JSON.parse(this.formD.music);
        audio.src = data.path;
        audio.pause();
        audio.load();
        audio.play();
      }
    },
    query() {
      if (!!this.form) {
        this.formD = this.form;
        this.play();
        return;
      }
      this.$http.get(url).then(({ data }) => {
        this.$http.get(url).then(({ data }) => {
          if (data.code == "0000") {
            this.formD = data.distribution;
            this.users = data.user;
            this.order = data.order;
            this.formD.music = JSON.parse(this.formD.music);
            var thumbnail = data.distribution.thumbnail;
            var currentUrl = encodeURIComponent(location.href.split("#")[0]);
            //encodeURIComponent(location.href.split('#')[0])
            this.$http
              .post(
                "https://wx.sharkmeida.cn/api/wxpay/initwxjs?url=" + currentUrl
              )
              .then(function(data, status) {
                wx.config({
                  debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                  appId: data.data.result.data.appId, // 必填，公众号的唯一标识
                  timestamp: data.data.result.data.timestamp, // 必填，生成签名的时间戳
                  nonceStr: data.data.result.data.nonceStr, // 必填，生成签名的随机串
                  signature: data.data.result.data.signature, // 必填，签名s
                  jsApiList: ["onMenuShareTimeline", "onMenuShareAppMessage"] // 必填，需要使用的JS接口列表
                });

                wx.ready(function() {
                  // alert('wx ready')

                  wx.error(function(res) {
                    // config 信息验证失败会执行 error 函数，如签名过期导致验证失败，具体错误信息可以打开 config 的 debug 模式查看，也可以在返回的 res 参数中查看，对于 SPA 可以在这里更新签名。
                    console.log(res);
                  });

                  wx.checkJsApi({
                    jsApiList: ["onMenuShareTimeline", "onMenuShareAppMessage"], // 需要检测的JS接口列表，所有JS接口列表见附录2,
                    success: function(res) {
                      // 以键值对的形式返回，可用的api值true，不可用为false
                      // 如：{"checkResult":{"chooseImage":true},"errMsg":"checkJsApi:ok"}
                      console.log("checkJsApi" + res);
                    }
                  });

                  var shareParam = {
                    title: "分销", // 分享标题
                    desc: "这是一条描述", // 分享描述
                    link: currentUrl, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
                    imgUrl: thumbnail, // 分享图标
                    // type: 'link', // 分享类型,music、video或link，不填默认为link
                    // dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
                    trigger: function(res) {
                      console.log("用户点击发送给朋友");
                    },
                    success: function(res) {
                      console.log("已分享");
                    },
                    cancel: function(res) {
                      console.log("已取消");
                    },
                    fail: function(res) {}
                  };

                  wx.onMenuShareTimeline(shareParam);
                  wx.onMenuShareAppMessage(shareParam);
                });
              });
          }
        });
      });
    }
  }
};
</script>

<style scoped>
.panel {
  background: #fff;
}
.panel-head {
  display: inline-block;
  font-family: "yahei";
  font-size: 0.4rem;
  height: 0.6rem;
  line-height: 0.6rem;
  color: #ef5a5a;
  border-bottom: 2px solid #ef5a5a;
}
.wrap-3 {
  display: flex;
  width: 8rem;
  padding: 1rem;
  overflow: auto;
  justify-content: flex-start;
  border-top: 1px solid #ccc;
  background: #fff;
  flex-wrap: wrap;
}
.wrap-3 > div {
  display: flex;
  width: 0.8rem;
  height: 1.7rem;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  margin: 0.2rem;
}
.wrap-3 img {
  height: 0.8rem;
  width: 0.8rem;
  border-radius: 50%;
}
.wrap-3 span {
  font-size: 0.3rem;
  display: inline-block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  width: 0.8rem;
}
.wrap-2 {
  display: flex;
  justify-content: space-between;
  height: 2rem;
  width: 8rem;
  padding: 0 1rem;
  background: #fff;
}
.wrap-2 .img {
  width: 2rem;
  height: 2rem;
}
.wrap-2 .text {
  width: 6rem;
  height: 2rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  font-family: "yahei";
  font-size: 0.2rem;
  line-height: 0.5rem;
}

.head-cell {
  height: 1.5rem;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  background: #ef5a5a;
}
.head-cell > div {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-size: 0.4rem;
  font-family: "yahei";
  color: #fff;
}
.head-cell > div.line {
  width: 5px;
  height: 80%;
  background: #fff;
}
.active {
  background: #ccc;
}
.music-wrap {
  position: fixed;
  overflow: auto;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  background: #fff;
  padding-bottom: 1.5rem;
}
.play {
  font-size: 0.5rem;
  color: #4e9cfd;
}
.stop {
  font-size: 0.5rem;
  color: #4e9cfd;
}
.tips-wrap {
  width: 9rem;
  margin: 0.5rem;
  font-size: 0.2rem;
  height: 3rem;
  border: 1px dashed #ccc;
  border-radius: 10px;
  text-align: center;
  color: #bfbdbd;
  font-family: yahei;
}
#contentBox {
  width: 10rem;
  background: #fff;
}
* {
  margin: 0;
  padding: 0;
}
.header-img {
  width: 10rem;
  height: 5rem;
  display: block;
}
.footer {
  position: fixed;
  bottom: 0;
  width: 10rem;
  height: 1.5rem;
  background: #fff;
  border-top: 1px solid #ccc;
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
}
.btn-h {
  width: 4rem;
  height: 1rem;
  border-radius: 0.5rem;
  line-height: 1rem;
  text-align: center;
  background: #699acc;
  color: #fff;
  font-size: 0.5rem;
}

.wrap {
  position: relative;
  padding: 1rem 0.4rem;
}
.middle {
  padding-bottom: 1.6rem;
}
.bg-1 {
  background: #fff;
  width: 8.8rem;
  padding: 0.2rem;
  border-radius: 0.2rem;
}
.bg-2 {
  background: #fff;
  width: 7.8rem;
  padding: 0.2rem;
  position: absolute;
  top: 0.7rem;
  height: 0.2rem;
  left: 50%;
  margin-left: -4.1rem;
}
.title {
  background: url(../assets/title.png) center no-repeat;
  border-radius: 1rem;
  background-size: cover;
  height: 1rem;
  width: 6rem;
  position: absolute;
  left: 50%;
  top: 0.1rem;
  margin-left: -3rem;
  font-size: 0.6rem;
  text-align: center;
  color: #fff;
  font-weight: bold;
  line-height: 1rem;
}
.content {
  min-height: 3rem;
  padding: 0.8rem 0 0 0;
  font-size: 0.4rem;
}
.circular {
  -webkit-box-align: center;
  -webkit-box-pack: center;
  align-items: center;
  background: rgba(0, 0, 0, 0.5);
  border-radius: 50%;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  font-size: 0.7rem;
  height: 1.5rem;
  justify-content: center;
  width: 1.5rem;
  position: fixed;
  top: 1rem;
  right: 0.3rem;
  z-index: 100;
}
</style>
