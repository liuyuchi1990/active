// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import FastClick from 'fastclick'
import VueRouter from 'vue-router'
import App from './App'
import Home from './components/HelloFromVux'
import  { ToastPlugin, LoadingPlugin, AlertPlugin  } from 'vux'
import { AjaxPlugin } from 'vux'

import './assets/scss/index.css'

Vue.use(AjaxPlugin)
Vue.use(ToastPlugin)
Vue.use(LoadingPlugin)
Vue.use(AlertPlugin)

// FastClick.attach(document.body)

// var html = document.documentElement;
// var width = html.getBoundingClientRect().width;
// html.style.fontSize = width / 10 + 'px';//至于除数15可自行设置

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  // router,
  render: h => h(App)
}).$mount('#app-box')
